const API_BASE = import.meta.env.VITE_API_URL || '/api';

function getToken() {
  return localStorage.getItem('lga_token');
}

async function request(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  if (res.status === 401) {
    localStorage.removeItem('lga_token');
    localStorage.removeItem('lga_user');
    window.location.href = '/login';
    throw new Error('Session expired');
  }

  // Handle file downloads
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/pdf') || contentType.includes('spreadsheet') || contentType.includes('octet-stream')) {
    if (!res.ok) throw new Error('Download failed');
    return res.blob();
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  // Auth
  login: (email, password) => request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  me: () => request('/auth/me'),

  // Students
  getStudents: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/students?${q}`);
  },
  getStudent: (id) => request(`/students/${id}`),
  createStudent: (data) => request('/students', { method: 'POST', body: JSON.stringify(data) }),
  updateStudent: (id, data) => request(`/students/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  enrolStudent: (id, data) => request(`/students/${id}/enrol`, { method: 'POST', body: JSON.stringify(data) }),

  // Payments
  getPayments: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/payments?${q}`);
  },
  createPayment: (data) => request('/payments', { method: 'POST', body: JSON.stringify(data) }),
  getStudentPayments: (studentId) => request(`/payments/student/${studentId}`),

  // Finance
  getFinance: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/finance?${q}`);
  },
  createFinance: (data) => request('/finance', { method: 'POST', body: JSON.stringify(data) }),
  getFinanceDashboard: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/finance/dashboard?${q}`);
  },

  // Academic
  getAcademic: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/academic?${q}`);
  },
  createAcademic: (data) => request('/academic', { method: 'POST', body: JSON.stringify(data) }),
  getStudentProgress: (studentId) => request(`/academic/student/${studentId}/progress`),

  // Attendance
  getAttendance: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/attendance?${q}`);
  },
  markAttendance: (data) => request('/attendance', { method: 'POST', body: JSON.stringify(data) }),
  bulkAttendance: (data) => request('/attendance/bulk', { method: 'POST', body: JSON.stringify(data) }),
  getAttendanceSummary: (studentId) => request(`/attendance/summary?studentId=${studentId}`),

  // Reports
  downloadStudentsPdf: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/reports/students/pdf?${q}`);
  },
  downloadStudentsExcel: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/reports/students/excel?${q}`);
  },
  downloadPaymentsExcel: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/reports/payments/excel?${q}`);
  },
  downloadAcademicPdf: (studentId) => request(`/reports/academic/${studentId}/pdf`),
};

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
