import React from 'react';
import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from './services/AuthContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Students from './pages/Students';
import Payments from './pages/Payments';
import Finance from './pages/Finance';
import Academic from './pages/Academic';
import Attendance from './pages/Attendance';
import Reports from './pages/Reports';

function Layout({ children, title }) {
  const { user, logout, hasRole } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/login');
  }

  const roleLabel = {
    MAIN_ADMIN: 'Main Administrator',
    TEACHER: 'Teacher',
    FINANCE_OFFICER: 'Finance Officer',
  };

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <h1>LIFELINE GLOBAL ACADEMY</h1>
          <span>Student Management System</span>
        </div>
        <nav className="sidebar-nav">
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/students">Students</NavLink>
          {(hasRole('MAIN_ADMIN', 'FINANCE_OFFICER', 'TEACHER')) && (
            <NavLink to="/payments">Payments</NavLink>
          )}
          {hasRole('MAIN_ADMIN', 'FINANCE_OFFICER') && (
            <NavLink to="/finance">Finance</NavLink>
          )}
          <NavLink to="/academic">Academic</NavLink>
          <NavLink to="/attendance">Attendance</NavLink>
          <NavLink to="/reports">Reports</NavLink>
        </nav>
        <div className="sidebar-footer">
          <div>{user?.fullName}</div>
          <div className="role">{roleLabel[user?.role] || user?.role}</div>
          <button className="btn btn-sm btn-secondary" style={{ marginTop: 10, width: '100%', justifyContent: 'center' }} onClick={handleLogout}>
            Logout
          </button>
        </div>
      </aside>
      <div className="main">
        <div className="topbar">
          <h2>{title}</h2>
        </div>
        <div className="content">{children}</div>
      </div>
    </div>
  );
}

function PrivateRoute({ children, title }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="login-page"><div style={{ color: '#fff' }}>Loading...</div></div>;
  if (!user) return <Navigate to="/login" replace />;
  return <Layout title={title}>{children}</Layout>;
}

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="login-page"><div style={{ color: '#fff' }}>Loading...</div></div>;
  }

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/" element={<PrivateRoute title="Dashboard"><Dashboard /></PrivateRoute>} />
      <Route path="/students" element={<PrivateRoute title="Students"><Students /></PrivateRoute>} />
      <Route path="/payments" element={<PrivateRoute title="Payments"><Payments /></PrivateRoute>} />
      <Route path="/finance" element={<PrivateRoute title="Finance"><Finance /></PrivateRoute>} />
      <Route path="/academic" element={<PrivateRoute title="Academic Performance"><Academic /></PrivateRoute>} />
      <Route path="/attendance" element={<PrivateRoute title="Attendance"><Attendance /></PrivateRoute>} />
      <Route path="/reports" element={<PrivateRoute title="Reports"><Reports /></PrivateRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
