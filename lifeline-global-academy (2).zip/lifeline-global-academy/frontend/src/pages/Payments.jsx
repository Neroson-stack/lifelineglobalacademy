import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function Payments() {
  const { hasRole } = useAuth();
  const [payments, setPayments] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    studentId: '', amount: '', paymentDate: new Date().toISOString().slice(0, 10),
    paymentMethod: 'Cash', description: 'Class fee',
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [payRes, stuRes] = await Promise.all([
        api.getPayments({ limit: 50 }),
        api.getStudents({ limit: 100, status: 'ACTIVE' }),
      ]);
      setPayments(payRes.data || []);
      setStudents(stuRes.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.createPayment({
        ...form,
        amount: Number(form.amount),
      });
      setShowModal(false);
      setForm({ studentId: '', amount: '', paymentDate: new Date().toISOString().slice(0, 10), paymentMethod: 'Cash', description: 'Class fee' });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="toolbar">
        {hasRole('MAIN_ADMIN', 'FINANCE_OFFICER') && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Record Payment</button>
        )}
      </div>

      <div className="card table-wrap">
        {loading ? (
          <div className="empty">Loading...</div>
        ) : payments.length === 0 ? (
          <div className="empty">No payments recorded</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Student</th>
                <th>Form/Class</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id}>
                  <td>{p.paymentDate?.slice?.(0, 10) || p.paymentDate}</td>
                  <td>
                    <strong>{p.student?.studentCode}</strong><br />
                    <span style={{ fontSize: 13 }}>{p.student?.firstName} {p.student?.lastName}</span>
                  </td>
                  <td>{p.student?.form}{p.student?.class}</td>
                  <td><strong>${Number(p.amount).toLocaleString()}</strong></td>
                  <td>{p.paymentMethod || '—'}</td>
                  <td>{p.description || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Record Fee Payment</h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label>Student *</label>
                <select required value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })}>
                  <option value="">Select student...</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.studentCode} – {s.firstName} {s.lastName} (Form {s.form}{s.class})
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Amount *</label>
                  <input type="number" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Date *</label>
                  <input type="date" required value={form.paymentDate} onChange={(e) => setForm({ ...form, paymentDate: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Method</label>
                  <select value={form.paymentMethod} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })}>
                    <option>Cash</option>
                    <option>Bank Transfer</option>
                    <option>Mobile Money</option>
                    <option>Cheque</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Description</label>
                  <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Record Payment'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
