import React, { useState } from 'react';
import { api, downloadBlob } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function Reports() {
  const { hasRole } = useAuth();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState('');

  async function download(name, fn, filename) {
    setError('');
    setBusy(name);
    try {
      const blob = await fn();
      downloadBlob(blob, filename);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginBottom: 12 }}>Student Reports</h3>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button
            className="btn btn-primary"
            disabled={!!busy}
            onClick={() => download('students-pdf', () => api.downloadStudentsPdf(), 'students.pdf')}
          >
            {busy === 'students-pdf' ? 'Generating...' : 'Students List (PDF)'}
          </button>
          <button
            className="btn btn-secondary"
            disabled={!!busy}
            onClick={() => download('students-xlsx', () => api.downloadStudentsExcel(), 'students.xlsx')}
          >
            {busy === 'students-xlsx' ? 'Generating...' : 'Students List (Excel)'}
          </button>
        </div>
      </div>

      {hasRole('MAIN_ADMIN', 'FINANCE_OFFICER') && (
        <div className="card" style={{ marginBottom: 16 }}>
          <h3 style={{ marginBottom: 12 }}>Financial Reports</h3>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <button
              className="btn btn-primary"
              disabled={!!busy}
              onClick={() => download('payments-xlsx', () => api.downloadPaymentsExcel(), 'payments.xlsx')}
            >
              {busy === 'payments-xlsx' ? 'Generating...' : 'Payments Export (Excel)'}
            </button>
          </div>
        </div>
      )}

      <div className="card">
        <h3 style={{ marginBottom: 8 }}>Academic Progress Reports</h3>
        <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 12 }}>
          Individual student academic PDF reports are available from the Academic module or via API:
          <code style={{ display: 'block', marginTop: 6, fontSize: 12 }}>GET /api/reports/academic/:studentId/pdf</code>
        </p>
      </div>
    </div>
  );
}
