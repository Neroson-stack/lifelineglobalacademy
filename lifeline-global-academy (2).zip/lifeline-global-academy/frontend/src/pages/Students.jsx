import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../services/AuthContext';

const emptyForm = {
  firstName: '', lastName: '', form: '1', class: 'A',
  desiredSubject: '', gender: '', guardianName: '', guardianPhone: '',
};

export default function Students() {
  const { hasRole } = useAuth();
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [formFilter, setFormFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const params = { limit: 50 };
      if (search) params.search = search;
      if (formFilter) params.form = formFilter;
      const res = await api.getStudents(params);
      setStudents(res.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.createStudent(form);
      setShowModal(false);
      setForm(emptyForm);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="toolbar">
        <input
          placeholder="Search name or code..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && load()}
        />
        <select value={formFilter} onChange={(e) => setFormFilter(e.target.value)}>
          <option value="">All Forms</option>
          {[1, 2, 3, 4, 5, 6].map((f) => (
            <option key={f} value={String(f)}>Form {f}</option>
          ))}
        </select>
        <button className="btn btn-secondary" onClick={load}>Search</button>
        {hasRole('MAIN_ADMIN', 'TEACHER') && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Student</button>
        )}
      </div>

      <div className="card table-wrap">
        {loading ? (
          <div className="empty">Loading...</div>
        ) : students.length === 0 ? (
          <div className="empty">No students found</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Form</th>
                <th>Class</th>
                <th>Desired Subject</th>
                <th>Guardian</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.id}>
                  <td><strong>{s.studentCode}</strong></td>
                  <td>{s.firstName} {s.lastName}</td>
                  <td>{s.form}</td>
                  <td>{s.class}</td>
                  <td>{s.desiredSubject || '—'}</td>
                  <td>{s.guardianName || '—'}</td>
                  <td>
                    <span className={`badge ${s.status === 'ACTIVE' ? 'badge-success' : 'badge-muted'}`}>
                      {s.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Add Student</h3>
            <form onSubmit={handleCreate}>
              <div className="form-row">
                <div className="form-group">
                  <label>First Name *</label>
                  <input required value={form.firstName} onChange={(e) => setForm({ ...form, firstName: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Last Name *</label>
                  <input required value={form.lastName} onChange={(e) => setForm({ ...form, lastName: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Form *</label>
                  <select value={form.form} onChange={(e) => setForm({ ...form, form: e.target.value })}>
                    {[1, 2, 3, 4, 5, 6].map((f) => <option key={f} value={String(f)}>{f}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Class *</label>
                  <select value={form.class} onChange={(e) => setForm({ ...form, class: e.target.value })}>
                    {['A', 'B', 'C', 'D'].map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Desired Subject</label>
                  <input value={form.desiredSubject} onChange={(e) => setForm({ ...form, desiredSubject: e.target.value })} placeholder="e.g. Medicine, Engineering" />
                </div>
                <div className="form-group">
                  <label>Gender</label>
                  <select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                    <option value="">—</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Guardian Name</label>
                  <input value={form.guardianName} onChange={(e) => setForm({ ...form, guardianName: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Guardian Phone</label>
                  <input value={form.guardianPhone} onChange={(e) => setForm({ ...form, guardianPhone: e.target.value })} />
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Student'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
