import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../services/AuthContext';

export default function Dashboard() {
  const { user, hasRole } = useAuth();
  const [stats, setStats] = useState({ students: 0, payments: 0, income: 0, expense: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [studentsRes, paymentsRes] = await Promise.all([
          api.getStudents({ limit: 1 }),
          api.getPayments({ limit: 1 }),
        ]);
        let income = 0, expense = 0;
        if (hasRole('MAIN_ADMIN', 'FINANCE_OFFICER')) {
          const dash = await api.getFinanceDashboard();
          income = dash.summary?.totalIncome || 0;
          expense = dash.summary?.totalExpense || 0;
        }
        setStats({
          students: studentsRes.pagination?.total || 0,
          payments: paymentsRes.pagination?.total || 0,
          income,
          expense,
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <div className="empty">Loading dashboard...</div>;

  return (
    <div>
      <p style={{ marginBottom: 20, color: 'var(--text-muted)' }}>
        Welcome back, <strong>{user?.fullName}</strong>
      </p>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="label">Active Students</div>
          <div className="value">{stats.students}</div>
        </div>
        <div className="stat-card">
          <div className="label">Fee Payments</div>
          <div className="value">{stats.payments}</div>
        </div>
        {hasRole('MAIN_ADMIN', 'FINANCE_OFFICER') && (
          <>
            <div className="stat-card">
              <div className="label">Total Income</div>
              <div className="value" style={{ color: 'var(--success)' }}>
                ${Number(stats.income).toLocaleString()}
              </div>
            </div>
            <div className="stat-card">
              <div className="label">Total Expenses</div>
              <div className="value" style={{ color: 'var(--danger)' }}>
                ${Number(stats.expense).toLocaleString()}
              </div>
            </div>
          </>
        )}
      </div>
      <div className="card">
        <h3 style={{ marginBottom: 12 }}>Quick Guide</h3>
        <ul style={{ paddingLeft: 20, fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.8 }}>
          <li><strong>Students</strong> – Register, view and enrol students by form & class</li>
          <li><strong>Payments</strong> – Record class fee payments (auto-adds to finance income)</li>
          <li><strong>Finance</strong> – Track income & expenses, view net position</li>
          <li><strong>Academic</strong> – Record tests; system flags PROGRESSING / REGRESSING</li>
          <li><strong>Attendance</strong> – Daily or bulk mark present / absent / late / excused</li>
          <li><strong>Reports</strong> – Download PDF and Excel exports</li>
        </ul>
      </div>
    </div>
  );
}
