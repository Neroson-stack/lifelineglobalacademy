import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../services/AuthContext';

const statusBadge = {
  PRESENT: 'badge-success',
  ABSENT: 'badge-danger',
  LATE: 'badge-warning',
  EXCUSED: 'badge-info',
};

export default function Attendance() {
  const { hasRole } = useAuth();
  const [records, setRecords] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [showBulk, setShowBulk] = useState(false);
  const [bulkMarks, setBulkMarks] = useState({});
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [attRes, stuRes] = await Promise.all([
        api.getAttendance({ limit: 50, date }),
        api.getStudents({ limit: 100, status: 'ACTIVE' }),
      ]);
      setRecords(attRes.data || []);
      setStudents(stuRes.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [date]);

  function openBulk() {
    const marks = {};
    students.forEach((s) => { marks[s.id] = 'PRESENT'; });
    // Pre-fill existing
    records.forEach((r) => { marks[r.studentId] = r.status; });
    setBulkMarks(marks);
    setShowBulk(true);
  }

  async function handleBulkSave() {
    setSaving(true);
    setError('');
    try {
      const recordsPayload = Object.entries(bulkMarks).map(([studentId, status]) => ({
        studentId,
        status,
      }));
      await api.bulkAttendance({ date, records: recordsPayload });
      setShowBulk(false);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="toolbar">
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        {hasRole('MAIN_ADMIN', 'TEACHER') && (
          <button className="btn btn-primary" onClick={openBulk}>Mark Attendance (Bulk)</button>
        )}
      </div>

      <div className="card table-wrap">
        {loading ? (
          <div className="empty">Loading...</div>
        ) : records.length === 0 ? (
          <div className="empty">No attendance records for this date. Use bulk mark to record.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Student</th>
                <th>Form/Class</th>
                <th>Status</th>
                <th>Remarks</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id}>
                  <td>
                    <strong>{r.student?.studentCode}</strong> – {r.student?.firstName} {r.student?.lastName}
                  </td>
                  <td>{r.student?.form}{r.student?.class}</td>
                  <td>
                    <span className={`badge ${statusBadge[r.status] || 'badge-muted'}`}>{r.status}</span>
                  </td>
                  <td>{r.remarks || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showBulk && (
        <div className="modal-overlay" onClick={() => setShowBulk(false)}>
          <div className="modal" style={{ maxWidth: 600 }} onClick={(e) => e.stopPropagation()}>
            <h3>Mark Attendance – {date}</h3>
            <div style={{ maxHeight: 400, overflowY: 'auto' }}>
              <table>
                <thead>
                  <tr>
                    <th>Student</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((s) => (
                    <tr key={s.id}>
                      <td>{s.studentCode} – {s.firstName} {s.lastName} ({s.form}{s.class})</td>
                      <td>
                        <select
                          value={bulkMarks[s.id] || 'PRESENT'}
                          onChange={(e) => setBulkMarks({ ...bulkMarks, [s.id]: e.target.value })}
                          style={{ width: 130 }}
                        >
                          <option value="PRESENT">Present</option>
                          <option value="ABSENT">Absent</option>
                          <option value="LATE">Late</option>
                          <option value="EXCUSED">Excused</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setShowBulk(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleBulkSave} disabled={saving}>
                {saving ? 'Saving...' : 'Save Attendance'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
