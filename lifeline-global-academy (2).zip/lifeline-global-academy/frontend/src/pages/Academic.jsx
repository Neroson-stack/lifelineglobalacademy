import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useAuth } from '../services/AuthContext';

const perfBadge = {
  PROGRESSING: 'badge-success',
  REGRESSING: 'badge-danger',
  STABLE: 'badge-info',
};

export default function Academic() {
  const { hasRole } = useAuth();
  const [records, setRecords] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    studentId: '', testName: '', subject: 'Mathematics',
    testDate: new Date().toISOString().slice(0, 10), score: '', maxScore: 100, teacherComment: '',
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [recRes, stuRes] = await Promise.all([
        api.getAcademic({ limit: 40 }),
        api.getStudents({ limit: 100, status: 'ACTIVE' }),
      ]);
      setRecords(recRes.data || []);
      setStudents(stuRes.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.createAcademic({
        ...form,
        score: form.score !== '' ? Number(form.score) : null,
        maxScore: Number(form.maxScore) || 100,
      });
      setShowModal(false);
      setForm({ studentId: '', testName: '', subject: 'Mathematics', testDate: new Date().toISOString().slice(0, 10), score: '', maxScore: 100, teacherComment: '' });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="toolbar">
        {hasRole('MAIN_ADMIN', 'TEACHER') && (
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Record Test Result</button>
        )}
      </div>

      <div className="card table-wrap">
        {loading ? (
          <div className="empty">Loading...</div>
        ) : records.length === 0 ? (
          <div className="empty">No academic records</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Student</th>
                <th>Test / Topic</th>
                <th>Subject</th>
                <th>Score</th>
                <th>Performance</th>
                <th>Comment</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id}>
                  <td>{String(r.testDate).slice(0, 10)}</td>
                  <td>
                    <strong>{r.student?.studentCode}</strong><br />
                    <span style={{ fontSize: 13 }}>{r.student?.firstName} {r.student?.lastName}</span>
                  </td>
                  <td>{r.testName}</td>
                  <td>{r.subject}</td>
                  <td>{r.score != null ? `${r.score}/${r.maxScore}` : '—'}</td>
                  <td>
                    {r.performance ? (
                      <span className={`badge ${perfBadge[r.performance] || 'badge-muted'}`}>{r.performance}</span>
                    ) : '—'}
                  </td>
                  <td style={{ maxWidth: 160, fontSize: 13 }}>{r.teacherComment || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Record Test Result</h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label>Student *</label>
                <select required value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })}>
                  <option value="">Select student...</option>
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>{s.studentCode} – {s.firstName} {s.lastName}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Test Name / Topic *</label>
                  <input required value={form.testName} onChange={(e) => setForm({ ...form, testName: e.target.value })} placeholder="e.g. Mid-Term Algebra" />
                </div>
                <div className="form-group">
                  <label>Subject *</label>
                  <input required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Test Date *</label>
                  <input type="date" required value={form.testDate} onChange={(e) => setForm({ ...form, testDate: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Score</label>
                  <input type="number" step="0.01" value={form.score} onChange={(e) => setForm({ ...form, score: e.target.value })} />
                </div>
              </div>
              <div className="form-group">
                <label>Teacher Comment</label>
                <input value={form.teacherComment} onChange={(e) => setForm({ ...form, teacherComment: e.target.value })} />
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>
                Performance (PROGRESSING / REGRESSING / STABLE) is calculated automatically by comparing with the previous score in the same subject.
              </p>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Result'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
