import React, { useEffect, useState } from 'react';
import { api } from '../services/api';

export default function Finance() {
  const [summary, setSummary] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    type: 'EXPENSE', category: '', amount: '',
    transactionDate: new Date().toISOString().slice(0, 10), description: '',
  });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [dash, list] = await Promise.all([
        api.getFinanceDashboard(),
        api.getFinance({ limit: 30 }),
      ]);
      setSummary(dash.summary);
      setTransactions(list.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await api.createFinance({ ...form, amount: Number(form.amount) });
      setShowModal(false);
      setForm({ type: 'EXPENSE', category: '', amount: '', transactionDate: new Date().toISOString().slice(0, 10), description: '' });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="empty">Loading...</div>;

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}
      {summary && (
        <div className="stat-grid">
          <div className="stat-card">
            <div className="label">Total Income</div>
            <div className="value" style={{ color: 'var(--success)' }}>${Number(summary.totalIncome).toLocaleString()}</div>
          </div>
          <div className="stat-card">
            <div className="label">Total Expenses</div>
            <div className="value" style={{ color: 'var(--danger)' }}>${Number(summary.totalExpense).toLocaleString()}</div>
          </div>
          <div className="stat-card">
            <div className="label">Net Position</div>
            <div className="value" style={{ color: summary.net >= 0 ? 'var(--success)' : 'var(--danger)' }}>
              ${Number(summary.net).toLocaleString()}
            </div>
          </div>
        </div>
      )}

      <div className="toolbar">
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add Transaction</button>
      </div>

      <div className="card table-wrap">
        {transactions.length === 0 ? (
          <div className="empty">No transactions</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Category</th>
                <th>Amount</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id}>
                  <td>{String(t.transactionDate).slice(0, 10)}</td>
                  <td>
                    <span className={`badge ${t.type === 'INCOME' ? 'badge-success' : 'badge-danger'}`}>
                      {t.type}
                    </span>
                  </td>
                  <td>{t.category}</td>
                  <td><strong>${Number(t.amount).toLocaleString()}</strong></td>
                  <td>{t.description || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Add Finance Transaction</h3>
            <form onSubmit={handleCreate}>
              <div className="form-row">
                <div className="form-group">
                  <label>Type *</label>
                  <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                    <option value="INCOME">Income</option>
                    <option value="EXPENSE">Expense</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Category *</label>
                  <input required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Utilities, Salaries, Grants" />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Amount *</label>
                  <input type="number" step="0.01" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Date *</label>
                  <input type="date" required value={form.transactionDate} onChange={(e) => setForm({ ...form, transactionDate: e.target.value })} />
                </div>
              </div>
              <div className="form-group">
                <label>Description</label>
                <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
