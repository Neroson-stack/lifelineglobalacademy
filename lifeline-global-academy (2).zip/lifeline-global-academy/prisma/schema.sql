-- LIFELINE GLOBAL ACADEMY Student Management System
-- Complete PostgreSQL Schema

-- Enums
CREATE TYPE role AS ENUM ('MAIN_ADMIN', 'TEACHER', 'FINANCE_OFFICER');
CREATE TYPE student_status AS ENUM ('ACTIVE', 'INACTIVE', 'GRADUATED', 'WITHDRAWN');
CREATE TYPE performance_status AS ENUM ('PROGRESSING', 'REGRESSING', 'STABLE');
CREATE TYPE attendance_status AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');
CREATE TYPE finance_type AS ENUM ('INCOME', 'EXPENSE');
CREATE TYPE enrolment_status AS ENUM ('ACTIVE', 'COMPLETED', 'WITHDRAWN');

-- Users & Security
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name     TEXT NOT NULL,
  role          role NOT NULL,
  is_active     BOOLEAN DEFAULT true,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Students
CREATE TABLE students (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_code    TEXT UNIQUE NOT NULL,
  first_name      TEXT NOT NULL,
  last_name       TEXT NOT NULL,
  date_of_birth   DATE,
  gender          TEXT,
  form            TEXT NOT NULL,
  class           TEXT NOT NULL,
  desired_subject TEXT,
  guardian_name   TEXT,
  guardian_phone  TEXT,
  guardian_email  TEXT,
  address         TEXT,
  status          student_status DEFAULT 'ACTIVE',
  enrolled_at     DATE DEFAULT CURRENT_DATE,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Enrolment
CREATE TABLE enrolments (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id     UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  academic_year  TEXT NOT NULL,
  form           TEXT NOT NULL,
  class          TEXT NOT NULL,
  subjects       TEXT[],
  enrolment_date DATE DEFAULT CURRENT_DATE,
  status         enrolment_status DEFAULT 'ACTIVE',
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, academic_year)
);

-- Payments (class fees)
CREATE TABLE payments (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id      UUID NOT NULL REFERENCES students(id),
  amount          DECIMAL(12,2) NOT NULL,
  currency        TEXT DEFAULT 'USD',
  payment_date    DATE NOT NULL,
  payment_method  TEXT,
  reference       TEXT,
  description     TEXT,
  recorded_by     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Finance (income + expenses)
CREATE TABLE finance_transactions (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type               finance_type NOT NULL,
  category           TEXT NOT NULL,
  amount             DECIMAL(12,2) NOT NULL,
  transaction_date   DATE NOT NULL,
  description        TEXT,
  related_payment_id UUID REFERENCES payments(id),
  recorded_by        UUID REFERENCES users(id),
  created_at         TIMESTAMPTZ DEFAULT NOW()
);

-- Academic Records / Tests
CREATE TABLE academic_records (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id      UUID NOT NULL REFERENCES students(id),
  test_name       TEXT NOT NULL,
  subject         TEXT NOT NULL,
  test_date       DATE NOT NULL,
  score           DECIMAL(5,2),
  max_score       DECIMAL(5,2) DEFAULT 100,
  grade           TEXT,
  performance     performance_status,
  teacher_comment TEXT,
  recorded_by     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Attendance
CREATE TABLE attendance (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id    UUID NOT NULL REFERENCES students(id),
  date          DATE NOT NULL,
  status        attendance_status NOT NULL,
  remarks       TEXT,
  recorded_by   UUID REFERENCES users(id),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(student_id, date)
);

-- Indexes
CREATE INDEX idx_students_form_class ON students(form, class);
CREATE INDEX idx_students_status ON students(status);
CREATE INDEX idx_payments_student ON payments(student_id);
CREATE INDEX idx_payments_date ON payments(payment_date);
CREATE INDEX idx_academic_student ON academic_records(student_id);
CREATE INDEX idx_academic_subject_date ON academic_records(subject, test_date);
CREATE INDEX idx_attendance_student_date ON attendance(student_id, date);
CREATE INDEX idx_attendance_date ON attendance(date);
CREATE INDEX idx_finance_type_date ON finance_transactions(type, transaction_date);
