const prisma = require('../utils/prisma');

async function listTransactions(req, res) {
  try {
    const { type, category, from, to, page = 1, limit = 30 } = req.query;
    const where = {};
    if (type) where.type = type;
    if (category) where.category = category;
    if (from || to) {
      where.transactionDate = {};
      if (from) where.transactionDate.gte = new Date(from);
      if (to) where.transactionDate.lte = new Date(to);
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [transactions, total] = await Promise.all([
      prisma.financeTransaction.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { transactionDate: 'desc' },
        include: {
          recordedBy: { select: { fullName: true } },
          relatedPayment: {
            select: {
              id: true,
              student: { select: { studentCode: true, firstName: true, lastName: true } },
            },
          },
        },
      }),
      prisma.financeTransaction.count({ where }),
    ]);

    res.json({
      data: transactions,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list finance transactions' });
  }
}

async function createTransaction(req, res) {
  try {
    const { type, category, amount, transactionDate, description } = req.body;
    if (!type || !category || !amount || !transactionDate) {
      return res.status(400).json({ error: 'type, category, amount and transactionDate are required' });
    }
    if (!['INCOME', 'EXPENSE'].includes(type)) {
      return res.status(400).json({ error: 'type must be INCOME or EXPENSE' });
    }

    const transaction = await prisma.financeTransaction.create({
      data: {
        type,
        category,
        amount,
        transactionDate: new Date(transactionDate),
        description,
        recordedById: req.user.id,
      },
    });

    res.status(201).json({ transaction });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create finance transaction' });
  }
}

async function getDashboard(req, res) {
  try {
    const { from, to } = req.query;
    const dateFilter = {};
    if (from) dateFilter.gte = new Date(from);
    if (to) dateFilter.lte = new Date(to);

    const where = Object.keys(dateFilter).length ? { transactionDate: dateFilter } : {};

    const [incomeAgg, expenseAgg, recent] = await Promise.all([
      prisma.financeTransaction.aggregate({
        where: { ...where, type: 'INCOME' },
        _sum: { amount: true },
        _count: true,
      }),
      prisma.financeTransaction.aggregate({
        where: { ...where, type: 'EXPENSE' },
        _sum: { amount: true },
        _count: true,
      }),
      prisma.financeTransaction.findMany({
        where,
        take: 10,
        orderBy: { transactionDate: 'desc' },
        include: { recordedBy: { select: { fullName: true } } },
      }),
    ]);

    const totalIncome = Number(incomeAgg._sum.amount || 0);
    const totalExpense = Number(expenseAgg._sum.amount || 0);

    res.json({
      summary: {
        totalIncome,
        totalExpense,
        net: totalIncome - totalExpense,
        incomeCount: incomeAgg._count,
        expenseCount: expenseAgg._count,
      },
      recentTransactions: recent,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load finance dashboard' });
  }
}

module.exports = {
  listTransactions,
  createTransaction,
  getDashboard,
};
