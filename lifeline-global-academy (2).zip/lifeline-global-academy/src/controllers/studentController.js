const prisma = require('../utils/prisma');

function generateStudentCode() {
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `LGA-${year}-${rand}`;
}

async function listStudents(req, res) {
  try {
    const { form, class: className, status, search, page = 1, limit = 20 } = req.query;
    const where = {};

    if (form) where.form = form;
    if (className) where.class = className;
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { studentCode: { contains: search, mode: 'insensitive' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [students, total] = await Promise.all([
      prisma.student.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: [{ form: 'asc' }, { class: 'asc' }, { lastName: 'asc' }],
        include: {
          enrolments: { where: { status: 'ACTIVE' }, take: 1 },
        },
      }),
      prisma.student.count({ where }),
    ]);

    res.json({
      data: students,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list students' });
  }
}

async function getStudent(req, res) {
  try {
    const student = await prisma.student.findUnique({
      where: { id: req.params.id },
      include: {
        enrolments: true,
        payments: { orderBy: { paymentDate: 'desc' }, take: 10 },
        academicRecords: { orderBy: { testDate: 'desc' }, take: 20 },
        attendance: { orderBy: { date: 'desc' }, take: 30 },
      },
    });
    if (!student) return res.status(404).json({ error: 'Student not found' });
    res.json({ student });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get student' });
  }
}

async function createStudent(req, res) {
  try {
    const {
      firstName, lastName, dateOfBirth, gender, form, class: className,
      desiredSubject, guardianName, guardianPhone, guardianEmail, address,
    } = req.body;

    if (!firstName || !lastName || !form || !className) {
      return res.status(400).json({ error: 'firstName, lastName, form and class are required' });
    }

    let studentCode = generateStudentCode();
    // ensure uniqueness
    while (await prisma.student.findUnique({ where: { studentCode } })) {
      studentCode = generateStudentCode();
    }

    const student = await prisma.student.create({
      data: {
        studentCode,
        firstName,
        lastName,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        gender,
        form,
        class: className,
        desiredSubject,
        guardianName,
        guardianPhone,
        guardianEmail,
        address,
      },
    });

    res.status(201).json({ student });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create student' });
  }
}

async function updateStudent(req, res) {
  try {
    const data = { ...req.body };
    if (data.class) {
      data.class = data.class;
      delete data.className;
    }
    if (data.dateOfBirth) data.dateOfBirth = new Date(data.dateOfBirth);

    const student = await prisma.student.update({
      where: { id: req.params.id },
      data,
    });
    res.json({ student });
  } catch (err) {
    if (err.code === 'P2025') return res.status(404).json({ error: 'Student not found' });
    console.error(err);
    res.status(500).json({ error: 'Failed to update student' });
  }
}

async function enrolStudent(req, res) {
  try {
    const { academicYear, form, class: className, subjects } = req.body;
    if (!academicYear || !form || !className) {
      return res.status(400).json({ error: 'academicYear, form and class are required' });
    }

    const enrolment = await prisma.enrolment.create({
      data: {
        studentId: req.params.id,
        academicYear,
        form,
        class: className,
        subjects: subjects || [],
      },
    });

    // also update student form/class
    await prisma.student.update({
      where: { id: req.params.id },
      data: { form, class: className },
    });

    res.status(201).json({ enrolment });
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ error: 'Student already enrolled for this academic year' });
    console.error(err);
    res.status(500).json({ error: 'Failed to enrol student' });
  }
}

module.exports = {
  listStudents,
  getStudent,
  createStudent,
  updateStudent,
  enrolStudent,
};
