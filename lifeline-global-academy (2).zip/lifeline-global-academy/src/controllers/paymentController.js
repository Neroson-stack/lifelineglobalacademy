const prisma = require('../utils/prisma');

async function listPayments(req, res) {
  try {
    const { studentId, from, to, page = 1, limit = 20 } = req.query;
    const where = {};
    if (studentId) where.studentId = studentId;
    if (from || to) {
      where.paymentDate = {};
      if (from) where.paymentDate.gte = new Date(from);
      if (to) where.paymentDate.lte = new Date(to);
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { paymentDate: 'desc' },
        include: {
          student: { select: { id: true, studentCode: true, firstName: true, lastName: true, form: true, class: true } },
          recordedBy: { select: { id: true, fullName: true } },
        },
      }),
      prisma.payment.count({ where }),
    ]);

    res.json({
      data: payments,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list payments' });
  }
}

async function createPayment(req, res) {
  try {
    const { studentId, amount, currency, paymentDate, paymentMethod, reference, description } = req.body;
    if (!studentId || !amount || !paymentDate) {
      return res.status(400).json({ error: 'studentId, amount and paymentDate are required' });
    }

    const student = await prisma.student.findUnique({ where: { id: studentId } });
    if (!student) return res.status(404).json({ error: 'Student not found' });

    const payment = await prisma.$transaction(async (tx) => {
      const p = await tx.payment.create({
        data: {
          studentId,
          amount,
          currency: currency || 'USD',
          paymentDate: new Date(paymentDate),
          paymentMethod,
          reference,
          description: description || 'Class fee',
          recordedById: req.user.id,
        },
        include: {
          student: { select: { studentCode: true, firstName: true, lastName: true } },
        },
      });

      // Auto-create corresponding INCOME finance transaction
      await tx.financeTransaction.create({
        data: {
          type: 'INCOME',
          category: 'Student Fees',
          amount,
          transactionDate: new Date(paymentDate),
          description: `Fee payment – ${p.student.firstName} ${p.student.lastName} (${p.student.studentCode})`,
          relatedPaymentId: p.id,
          recordedById: req.user.id,
        },
      });

      return p;
    });

    res.status(201).json({ payment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to record payment' });
  }
}

async function getStudentPaymentSummary(req, res) {
  try {
    const studentId = req.params.studentId;
    const payments = await prisma.payment.findMany({
      where: { studentId },
      orderBy: { paymentDate: 'desc' },
    });

    const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0);
    res.json({
      studentId,
      totalPaid,
      currency: payments[0]?.currency || 'USD',
      paymentCount: payments.length,
      payments,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get payment summary' });
  }
}

module.exports = {
  listPayments,
  createPayment,
  getStudentPaymentSummary,
};
