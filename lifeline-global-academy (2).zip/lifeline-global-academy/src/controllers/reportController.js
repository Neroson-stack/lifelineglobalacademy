const prisma = require('../utils/prisma');
const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');

async function studentListPdf(req, res) {
  try {
    const { form, class: className } = req.query;
    const where = { status: 'ACTIVE' };
    if (form) where.form = form;
    if (className) where.class = className;

    const students = await prisma.student.findMany({
      where,
      orderBy: [{ form: 'asc' }, { class: 'asc' }, { lastName: 'asc' }],
    });

    const doc = new PDFDocument({ margin: 40 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=students.pdf');
    doc.pipe(res);

    doc.fontSize(18).text('LIFELINE GLOBAL ACADEMY', { align: 'center' });
    doc.fontSize(14).text('Student List', { align: 'center' });
    doc.moveDown();
    if (form || className) {
      doc.fontSize(10).text(`Filter: Form ${form || 'All'} / Class ${className || 'All'}`);
      doc.moveDown(0.5);
    }

    doc.fontSize(9);
    students.forEach((s, i) => {
      doc.text(
        `${i + 1}. ${s.studentCode}  |  ${s.lastName}, ${s.firstName}  |  Form ${s.form}${s.class}  |  ${s.desiredSubject || '-'}`
      );
    });

    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
}

async function studentListExcel(req, res) {
  try {
    const { form, class: className } = req.query;
    const where = { status: 'ACTIVE' };
    if (form) where.form = form;
    if (className) where.class = className;

    const students = await prisma.student.findMany({
      where,
      orderBy: [{ form: 'asc' }, { class: 'asc' }, { lastName: 'asc' }],
    });

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Students');
    sheet.columns = [
      { header: 'Student Code', key: 'studentCode', width: 16 },
      { header: 'First Name', key: 'firstName', width: 15 },
      { header: 'Last Name', key: 'lastName', width: 15 },
      { header: 'Form', key: 'form', width: 10 },
      { header: 'Class', key: 'class', width: 10 },
      { header: 'Desired Subject', key: 'desiredSubject', width: 18 },
      { header: 'Guardian', key: 'guardianName', width: 20 },
      { header: 'Phone', key: 'guardianPhone', width: 15 },
      { header: 'Status', key: 'status', width: 12 },
    ];
    students.forEach((s) => sheet.addRow(s));

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=students.xlsx');
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate Excel' });
  }
}

async function paymentsExcel(req, res) {
  try {
    const { from, to } = req.query;
    const where = {};
    if (from || to) {
      where.paymentDate = {};
      if (from) where.paymentDate.gte = new Date(from);
      if (to) where.paymentDate.lte = new Date(to);
    }

    const payments = await prisma.payment.findMany({
      where,
      orderBy: { paymentDate: 'desc' },
      include: {
        student: { select: { studentCode: true, firstName: true, lastName: true, form: true, class: true } },
      },
    });

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Payments');
    sheet.columns = [
      { header: 'Date', key: 'date', width: 12 },
      { header: 'Student Code', key: 'code', width: 14 },
      { header: 'Student Name', key: 'name', width: 22 },
      { header: 'Form/Class', key: 'formClass', width: 12 },
      { header: 'Amount', key: 'amount', width: 12 },
      { header: 'Method', key: 'method', width: 12 },
      { header: 'Reference', key: 'reference', width: 16 },
      { header: 'Description', key: 'description', width: 25 },
    ];

    payments.forEach((p) => {
      sheet.addRow({
        date: p.paymentDate.toISOString().slice(0, 10),
        code: p.student.studentCode,
        name: `${p.student.firstName} ${p.student.lastName}`,
        formClass: `${p.student.form}${p.student.class}`,
        amount: Number(p.amount),
        method: p.paymentMethod,
        reference: p.reference,
        description: p.description,
      });
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=payments.xlsx');
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate payments Excel' });
  }
}

async function academicReportPdf(req, res) {
  try {
    const studentId = req.params.studentId;
    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: {
        academicRecords: { orderBy: [{ subject: 'asc' }, { testDate: 'desc' }] },
      },
    });
    if (!student) return res.status(404).json({ error: 'Student not found' });

    const doc = new PDFDocument({ margin: 40 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=academic-${student.studentCode}.pdf`
    );
    doc.pipe(res);

    doc.fontSize(16).text('LIFELINE GLOBAL ACADEMY', { align: 'center' });
    doc.fontSize(12).text('Academic Progress Report', { align: 'center' });
    doc.moveDown();
    doc.fontSize(10).text(`Student: ${student.firstName} ${student.lastName} (${student.studentCode})`);
    doc.text(`Form/Class: ${student.form}${student.class}`);
    doc.text(`Desired Subject: ${student.desiredSubject || 'N/A'}`);
    doc.moveDown();

    const bySubject = {};
    student.academicRecords.forEach((r) => {
      if (!bySubject[r.subject]) bySubject[r.subject] = [];
      bySubject[r.subject].push(r);
    });

    Object.entries(bySubject).forEach(([subject, records]) => {
      doc.fontSize(11).text(subject, { underline: true });
      records.forEach((r) => {
        const perf = r.performance ? ` [${r.performance}]` : '';
        doc.fontSize(9).text(
          `  ${r.testDate.toISOString().slice(0, 10)}  |  ${r.testName}  |  Score: ${r.score ?? '-'}/${r.maxScore}${perf}`
        );
        if (r.teacherComment) doc.text(`    Comment: ${r.teacherComment}`);
      });
      doc.moveDown(0.5);
    });

    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate academic report' });
  }
}

module.exports = {
  studentListPdf,
  studentListExcel,
  paymentsExcel,
  academicReportPdf,
};
