const prisma = require('../utils/prisma');

function determinePerformance(previousScore, currentScore) {
  if (previousScore == null || currentScore == null) return null;
  const prev = Number(previousScore);
  const curr = Number(currentScore);
  if (curr > prev + 2) return 'PROGRESSING';
  if (curr < prev - 2) return 'REGRESSING';
  return 'STABLE';
}

async function listRecords(req, res) {
  try {
    const { studentId, subject, from, to, page = 1, limit = 30 } = req.query;
    const where = {};
    if (studentId) where.studentId = studentId;
    if (subject) where.subject = subject;
    if (from || to) {
      where.testDate = {};
      if (from) where.testDate.gte = new Date(from);
      if (to) where.testDate.lte = new Date(to);
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [records, total] = await Promise.all([
      prisma.academicRecord.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { testDate: 'desc' },
        include: {
          student: { select: { id: true, studentCode: true, firstName: true, lastName: true, form: true, class: true } },
          recordedBy: { select: { fullName: true } },
        },
      }),
      prisma.academicRecord.count({ where }),
    ]);

    res.json({
      data: records,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list academic records' });
  }
}

async function createRecord(req, res) {
  try {
    const { studentId, testName, subject, testDate, score, maxScore, grade, teacherComment } = req.body;
    if (!studentId || !testName || !subject || !testDate) {
      return res.status(400).json({ error: 'studentId, testName, subject and testDate are required' });
    }

    // Find previous record in same subject for performance status
    const previous = await prisma.academicRecord.findFirst({
      where: { studentId, subject },
      orderBy: { testDate: 'desc' },
    });

    const performance = determinePerformance(previous?.score, score);

    const record = await prisma.academicRecord.create({
      data: {
        studentId,
        testName,
        subject,
        testDate: new Date(testDate),
        score: score != null ? score : null,
        maxScore: maxScore || 100,
        grade,
        performance,
        teacherComment,
        recordedById: req.user.id,
      },
      include: {
        student: { select: { studentCode: true, firstName: true, lastName: true } },
      },
    });

    res.status(201).json({ record });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create academic record' });
  }
}

async function getStudentProgress(req, res) {
  try {
    const studentId = req.params.studentId;
    const records = await prisma.academicRecord.findMany({
      where: { studentId },
      orderBy: [{ subject: 'asc' }, { testDate: 'asc' }],
    });

    // Group by subject
    const bySubject = {};
    for (const r of records) {
      if (!bySubject[r.subject]) bySubject[r.subject] = [];
      bySubject[r.subject].push(r);
    }

    const summary = Object.entries(bySubject).map(([subject, items]) => {
      const latest = items[items.length - 1];
      return {
        subject,
        testCount: items.length,
        latestScore: latest.score,
        latestPerformance: latest.performance,
        trend: latest.performance,
      };
    });

    res.json({ studentId, summary, records });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get student progress' });
  }
}

module.exports = {
  listRecords,
  createRecord,
  getStudentProgress,
};
