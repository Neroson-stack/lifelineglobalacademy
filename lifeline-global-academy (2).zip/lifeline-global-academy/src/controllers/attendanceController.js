const prisma = require('../utils/prisma');

async function listAttendance(req, res) {
  try {
    const { studentId, form, class: className, date, from, to, page = 1, limit = 50 } = req.query;
    const where = {};

    if (studentId) where.studentId = studentId;
    if (date) where.date = new Date(date);
    if (from || to) {
      where.date = {};
      if (from) where.date.gte = new Date(from);
      if (to) where.date.lte = new Date(to);
    }

    // Filter by form/class via student relation
    if (form || className) {
      where.student = {};
      if (form) where.student.form = form;
      if (className) where.student.class = className;
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [records, total] = await Promise.all([
      prisma.attendance.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: [{ date: 'desc' }, { student: { lastName: 'asc' } }],
        include: {
          student: { select: { id: true, studentCode: true, firstName: true, lastName: true, form: true, class: true } },
          recordedBy: { select: { fullName: true } },
        },
      }),
      prisma.attendance.count({ where }),
    ]);

    res.json({
      data: records,
      pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list attendance' });
  }
}

async function markAttendance(req, res) {
  try {
    const { studentId, date, status, remarks } = req.body;
    if (!studentId || !date || !status) {
      return res.status(400).json({ error: 'studentId, date and status are required' });
    }
    if (!['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const record = await prisma.attendance.upsert({
      where: {
        studentId_date: {
          studentId,
          date: new Date(date),
        },
      },
      update: {
        status,
        remarks,
        recordedById: req.user.id,
      },
      create: {
        studentId,
        date: new Date(date),
        status,
        remarks,
        recordedById: req.user.id,
      },
      include: {
        student: { select: { studentCode: true, firstName: true, lastName: true } },
      },
    });

    res.status(201).json({ record });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to mark attendance' });
  }
}

async function bulkMarkAttendance(req, res) {
  try {
    const { date, records } = req.body; // records: [{ studentId, status, remarks? }]
    if (!date || !Array.isArray(records) || records.length === 0) {
      return res.status(400).json({ error: 'date and records array are required' });
    }

    const results = [];
    for (const r of records) {
      if (!r.studentId || !r.status) continue;
      const record = await prisma.attendance.upsert({
        where: {
          studentId_date: {
            studentId: r.studentId,
            date: new Date(date),
          },
        },
        update: {
          status: r.status,
          remarks: r.remarks,
          recordedById: req.user.id,
        },
        create: {
          studentId: r.studentId,
          date: new Date(date),
          status: r.status,
          remarks: r.remarks,
          recordedById: req.user.id,
        },
      });
      results.push(record);
    }

    res.status(201).json({ marked: results.length, records: results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to bulk mark attendance' });
  }
}

async function getAttendanceSummary(req, res) {
  try {
    const { studentId, from, to } = req.query;
    if (!studentId) return res.status(400).json({ error: 'studentId is required' });

    const where = { studentId };
    if (from || to) {
      where.date = {};
      if (from) where.date.gte = new Date(from);
      if (to) where.date.lte = new Date(to);
    }

    const records = await prisma.attendance.findMany({ where });
    const total = records.length;
    const present = records.filter((r) => r.status === 'PRESENT').length;
    const late = records.filter((r) => r.status === 'LATE').length;
    const absent = records.filter((r) => r.status === 'ABSENT').length;
    const excused = records.filter((r) => r.status === 'EXCUSED').length;
    const percentage = total ? Math.round(((present + late) / total) * 1000) / 10 : 0;

    res.json({
      studentId,
      totalDays: total,
      present,
      late,
      absent,
      excused,
      attendancePercentage: percentage,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to get attendance summary' });
  }
}

module.exports = {
  listAttendance,
  markAttendance,
  bulkMarkAttendance,
  getAttendanceSummary,
};
