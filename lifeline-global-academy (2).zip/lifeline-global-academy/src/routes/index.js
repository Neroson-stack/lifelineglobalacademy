const express = require('express');
const { authenticate, requireRoles } = require('../middleware/auth');

const authController = require('../controllers/authController');
const studentController = require('../controllers/studentController');
const paymentController = require('../controllers/paymentController');
const financeController = require('../controllers/financeController');
const academicController = require('../controllers/academicController');
const attendanceController = require('../controllers/attendanceController');
const reportController = require('../controllers/reportController');

const router = express.Router();

// ---------- Auth ----------
router.post('/auth/login', authController.login);
router.get('/auth/me', authenticate, authController.me);
router.post('/auth/users', authenticate, requireRoles('MAIN_ADMIN'), authController.createUser);

// ---------- Students & Enrolment ----------
router.get('/students', authenticate, studentController.listStudents);
router.get('/students/:id', authenticate, studentController.getStudent);
router.post('/students', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), studentController.createStudent);
router.patch('/students/:id', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), studentController.updateStudent);
router.post('/students/:id/enrol', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), studentController.enrolStudent);

// ---------- Payments ----------
router.get('/payments', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER', 'TEACHER'), paymentController.listPayments);
router.post('/payments', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER'), paymentController.createPayment);
router.get('/payments/student/:studentId', authenticate, paymentController.getStudentPaymentSummary);

// ---------- Finance (income + expenses) ----------
router.get('/finance', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER'), financeController.listTransactions);
router.post('/finance', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER'), financeController.createTransaction);
router.get('/finance/dashboard', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER'), financeController.getDashboard);

// ---------- Academic Performance ----------
router.get('/academic', authenticate, academicController.listRecords);
router.post('/academic', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), academicController.createRecord);
router.get('/academic/student/:studentId/progress', authenticate, academicController.getStudentProgress);

// ---------- Attendance ----------
router.get('/attendance', authenticate, attendanceController.listAttendance);
router.post('/attendance', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), attendanceController.markAttendance);
router.post('/attendance/bulk', authenticate, requireRoles('MAIN_ADMIN', 'TEACHER'), attendanceController.bulkMarkAttendance);
router.get('/attendance/summary', authenticate, attendanceController.getAttendanceSummary);

// ---------- Reports (PDF + Excel) ----------
router.get('/reports/students/pdf', authenticate, reportController.studentListPdf);
router.get('/reports/students/excel', authenticate, reportController.studentListExcel);
router.get('/reports/payments/excel', authenticate, requireRoles('MAIN_ADMIN', 'FINANCE_OFFICER'), reportController.paymentsExcel);
router.get('/reports/academic/:studentId/pdf', authenticate, reportController.academicReportPdf);

// Health
router.get('/health', (req, res) => res.json({ status: 'ok', service: 'LIFELINE GLOBAL ACADEMY SMS' }));

module.exports = router;
