require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding LIFELINE GLOBAL ACADEMY database...');

  // Users
  const passwordHash = await bcrypt.hash('Password123!', 12);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@lifeline.academy' },
    update: {},
    create: {
      email: 'admin@lifeline.academy',
      passwordHash,
      fullName: 'Main Administrator',
      role: 'MAIN_ADMIN',
    },
  });

  const teacher = await prisma.user.upsert({
    where: { email: 'teacher@lifeline.academy' },
    update: {},
    create: {
      email: 'teacher@lifeline.academy',
      passwordHash,
      fullName: 'Jane Teacher',
      role: 'TEACHER',
    },
  });

  const finance = await prisma.user.upsert({
    where: { email: 'finance@lifeline.academy' },
    update: {},
    create: {
      email: 'finance@lifeline.academy',
      passwordHash,
      fullName: 'John Finance',
      role: 'FINANCE_OFFICER',
    },
  });

  console.log('Users created:', { admin: admin.email, teacher: teacher.email, finance: finance.email });

  // Sample students
  const studentsData = [
    { firstName: 'Amina', lastName: 'Okello', form: '1', class: 'A', desiredSubject: 'Medicine', gender: 'F' },
    { firstName: 'Brian', lastName: 'Mwangi', form: '1', class: 'A', desiredSubject: 'Engineering', gender: 'M' },
    { firstName: 'Chloe', lastName: 'Ndlovu', form: '2', class: 'B', desiredSubject: 'Law', gender: 'F' },
    { firstName: 'David', lastName: 'Kariuki', form: '2', class: 'B', desiredSubject: 'Computer Science', gender: 'M' },
    { firstName: 'Esther', lastName: 'Wanjiku', form: '3', class: 'A', desiredSubject: 'Business', gender: 'F' },
  ];

  const students = [];
  for (let i = 0; i < studentsData.length; i++) {
    const s = studentsData[i];
    const studentCode = `LGA-2026-${1001 + i}`;
    const student = await prisma.student.upsert({
      where: { studentCode },
      update: {},
      create: {
        studentCode,
        firstName: s.firstName,
        lastName: s.lastName,
        form: s.form,
        class: s.class,
        desiredSubject: s.desiredSubject,
        gender: s.gender,
        guardianName: `Guardian of ${s.firstName}`,
        guardianPhone: `+25470000${1000 + i}`,
      },
    });
    students.push(student);

    // Enrolment
    await prisma.enrolment.upsert({
      where: {
        studentId_academicYear: {
          studentId: student.id,
          academicYear: '2025/2026',
        },
      },
      update: {},
      create: {
        studentId: student.id,
        academicYear: '2025/2026',
        form: s.form,
        class: s.class,
        subjects: ['Mathematics', 'English', 'Science', s.desiredSubject || 'General'],
      },
    });
  }

  console.log(`Created ${students.length} students with enrolments`);

  // Sample payments
  for (const student of students.slice(0, 3)) {
    await prisma.payment.create({
      data: {
        studentId: student.id,
        amount: 250,
        currency: 'USD',
        paymentDate: new Date('2026-01-15'),
        paymentMethod: 'Bank Transfer',
        reference: `FEE-${student.studentCode}`,
        description: 'Term 1 Fees',
        recordedById: finance.id,
      },
    });
  }
  console.log('Sample payments created');

  // Sample academic records
  for (const student of students) {
    await prisma.academicRecord.create({
      data: {
        studentId: student.id,
        testName: 'Mid-Term Mathematics',
        subject: 'Mathematics',
        testDate: new Date('2026-03-10'),
        score: 65 + Math.floor(Math.random() * 30),
        maxScore: 100,
        performance: 'STABLE',
        teacherComment: 'Good effort',
        recordedById: teacher.id,
      },
    });
    await prisma.academicRecord.create({
      data: {
        studentId: student.id,
        testName: 'End-Term Mathematics',
        subject: 'Mathematics',
        testDate: new Date('2026-06-15'),
        score: 70 + Math.floor(Math.random() * 25),
        maxScore: 100,
        performance: 'PROGRESSING',
        teacherComment: 'Improvement noted',
        recordedById: teacher.id,
      },
    });
  }
  console.log('Sample academic records created');

  // Sample attendance
  const today = new Date();
  for (const student of students) {
    await prisma.attendance.create({
      data: {
        studentId: student.id,
        date: today,
        status: Math.random() > 0.15 ? 'PRESENT' : 'ABSENT',
        recordedById: teacher.id,
      },
    });
  }
  console.log('Sample attendance created');

  // Sample expense
  await prisma.financeTransaction.create({
    data: {
      type: 'EXPENSE',
      category: 'Utilities',
      amount: 450,
      transactionDate: new Date('2026-02-01'),
      description: 'Electricity & Water – February',
      recordedById: finance.id,
    },
  });

  console.log('\n✅ Seed complete!');
  console.log('\nLogin credentials (password for all: Password123!):');
  console.log('  Main Admin:       admin@lifeline.academy');
  console.log('  Teacher:          teacher@lifeline.academy');
  console.log('  Finance Officer:  finance@lifeline.academy');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
